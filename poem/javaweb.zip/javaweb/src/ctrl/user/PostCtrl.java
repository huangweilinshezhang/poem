package ctrl.user;

import org.springframework.stereotype.Controller;

@Controller
public class PostCtrl {

}
