package model.user;

import java.util.List;


public class UserBeanListVo {
	List<UserBean> data;

	public List<UserBean> getData() {
		return data;
	}

	public void setData(List<UserBean> data) {
		this.data = data;
	}
}
