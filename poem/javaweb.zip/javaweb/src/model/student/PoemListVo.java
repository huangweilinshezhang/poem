package model.student;

import java.util.List;

public class PoemListVo {
	List<Poem> data;

	public List<Poem> getData() {
		return data;
	}

	public void setData(List<Poem> data) {
		this.data = data;
	}

}
