package model.student;

public class Poet {
	private int id;
	private String poet;
	private String msg;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPoet() {
		return poet;
	}
	public void setPoet(String poet) {
		this.poet = poet;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
}
